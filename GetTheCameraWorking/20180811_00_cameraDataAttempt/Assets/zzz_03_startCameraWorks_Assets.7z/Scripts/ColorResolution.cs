﻿using System;
using System.Collections.Generic;
using System.Text;

namespace zeroonetwo
{
    public enum ColorResolution
    {
        OFF = 0,
        _720P,
        _1080P,
        _1440P,
        _1536P,
        _2160P,
        _3072P,
    }
}
