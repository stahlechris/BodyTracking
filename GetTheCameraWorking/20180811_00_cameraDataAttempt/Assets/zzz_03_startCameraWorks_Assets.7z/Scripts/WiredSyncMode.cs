﻿using System;
using System.Collections.Generic;
using System.Text;

namespace zeroonetwo
{
    public enum WiredSyncMode
    {
        Standalone,
        Master,
        Subordinate
    }
}
