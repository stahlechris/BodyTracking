﻿using System;
using System.Collections.Generic;
using System.Text;

namespace zeroonetwo
{
    public enum Fps
    {
        _5 = 0,
        _15,
        _30,
    }
}
