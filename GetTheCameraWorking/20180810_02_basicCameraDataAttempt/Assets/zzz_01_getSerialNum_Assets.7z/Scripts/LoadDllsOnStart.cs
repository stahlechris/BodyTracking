﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.InteropServices;
using UnityEngine;
// ...
namespace zeroonetwo
{
	public class LoadDllsOnStart : MonoBehaviour
	{
		const string k4a = "k4a.dll";

		[DllImport("DllHelloWorld")]
		public static extern int DisplayHelloFromDLL();

		[DllImport(k4a)]
		public static extern uint k4a_device_get_installed_count();
		
		
		[DllImport(k4a)]
		public extern static k4a_result_t k4a_device_open(UInt32 index, out IntPtr device_handle);
		
		[DllImport(k4a)]
		public extern static void k4a_device_close(IntPtr device_handle);

		
        [DllImport(k4a)]
        public extern static k4a_buffer_result_t k4a_device_get_serialnum(IntPtr device_handle, IntPtr serial_number, ref UInt64 serial_number_size);

        internal IntPtr device_handle = IntPtr.Zero; // 1265321712
        internal IntPtr device_serial_num = IntPtr.Zero; // 1265321712
		void Start()
		{
			Debug.Log("Time is " + DateTime.Now.ToString("h:mm:ss tt") + ". Dll test: " + DisplayHelloFromDLL());
			Debug.Log("loc:\n" + Assembly.GetExecutingAssembly().Location);
			Debug.Log(k4a_device_get_installed_count());
			
			k4a_result_t result = k4a_device_open(0, out device_handle);
			Debug.Log(device_handle);

			UInt64 size = 13;
			Marshal.AllocHGlobal((int)size);
			k4a_buffer_result_t buffer_Result_T = k4a_device_get_serialnum(device_handle, device_serial_num, ref size);

			Debug.Log(size);
			Debug.Log(buffer_Result_T);
			k4a_device_close(device_handle);

			Debug.Log("Exit");
		}

	}

}

