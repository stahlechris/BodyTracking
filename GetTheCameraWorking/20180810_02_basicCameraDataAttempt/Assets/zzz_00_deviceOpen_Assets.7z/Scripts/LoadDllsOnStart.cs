﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using UnityEngine;

namespace zeroonetwo
{
	public class LoadDllsOnStart : MonoBehaviour
	{
		const string k4a = "k4a.dll";

		[DllImport("DllHelloWorld")]
		public static extern int DisplayHelloFromDLL();

		[DllImport(k4a)]
		public static extern uint k4a_device_get_installed_count();
		
		
		[DllImport(k4a)]
		public extern static k4a_result_t k4a_device_open(UInt32 index, out IntPtr device_handle);
		
		[DllImport(k4a)]
		public extern static void k4a_device_close(IntPtr device_handle);

        internal IntPtr device_handle = IntPtr.Zero; // 1265321712
		void Start()
		{
			Debug.Log("Time is " + DateTime.Now.ToString("h:mm:ss tt"));
			Debug.Log(DisplayHelloFromDLL());
			Debug.Log(k4a_device_get_installed_count());
			
			k4a_result_t result = k4a_device_open(0, out device_handle);
			Debug.Log(device_handle);

			k4a_device_close(device_handle);

			Debug.Log("Exit");
		}

	}

}

